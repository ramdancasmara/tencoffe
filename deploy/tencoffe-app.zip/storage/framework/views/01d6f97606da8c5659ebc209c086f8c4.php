
<?php $__env->startSection('title', 'Lacak Pesanan - TenCoffe'); ?>
<?php $__env->startSection('content'); ?>

<div class="pt-20 pb-16 min-h-screen bg-coffee-50">
    <div class="max-w-xl mx-auto px-4 sm:px-6 pt-8">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-extrabold text-coffee-800">🔍 Lacak Pesanan</h1>
            <p class="text-coffee-500 mt-2">Masukkan nomor pesanan untuk melihat status</p>
        </div>

        <div class="bg-white rounded-2xl p-6 shadow-sm">
            <form action="<?php echo e(route('order.track.search')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="flex gap-3">
                    <input type="text" name="order_number" placeholder="Contoh: TEN260222-0001" value="<?php echo e(old('order_number')); ?>" required class="input-field flex-1">
                    <button type="submit" class="btn-primary px-6 rounded-xl">Cari</button>
                </div>
            </form>
        </div>

        <?php if(isset($order) && $order): ?>
            <div class="mt-8 bg-white rounded-2xl p-6 shadow-sm">
                <div class="text-center mb-4">
                    <p class="text-lg font-bold text-coffee-800"><?php echo e($order->order_number); ?></p>
                    <span class="inline-block px-4 py-1 rounded-full text-sm font-bold <?php echo e($order->status_color); ?> mt-2"><?php echo e($order->status_label); ?></span>
                </div>
                <div class="space-y-2 text-sm text-gray-600">
                    <p><strong>Nama:</strong> <?php echo e($order->customer_name); ?></p>
                    <p><strong>Tanggal:</strong> <?php echo e($order->created_at->format('d M Y H:i')); ?></p>
                    <p><strong>Total:</strong> <?php echo e($order->formatted_total); ?></p>
                </div>
                <div class="mt-4 border-t border-gray-100 pt-4">
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between text-sm mb-1">
                            <span><?php echo e($item->product_name); ?> x<?php echo e($item->quantity); ?></span>
                            <span>Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php elseif(isset($order) && !$order): ?>
            <div class="mt-8 bg-red-50 rounded-2xl p-6 text-center">
                <p class="text-red-600 font-medium">Pesanan tidak ditemukan</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/order-track.blade.php ENDPATH**/ ?>