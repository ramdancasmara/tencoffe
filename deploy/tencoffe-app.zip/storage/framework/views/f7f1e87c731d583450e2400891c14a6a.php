
<div class="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-lg transition-all hover:-translate-y-1 group"
     x-data="{ variant: '<?php echo e($product->has_variants ? 'hot' : ''); ?>', price: <?php echo e($product->display_price); ?> }">
    
    <div class="relative overflow-hidden aspect-square">
        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
        
        <div class="absolute top-3 left-3 flex flex-col gap-1">
            <?php if($product->is_new): ?>
                <span class="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">Baru</span>
            <?php endif; ?>
            <?php if($product->is_promo): ?>
                <span class="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">Promo</span>
            <?php endif; ?>
            <?php if($product->is_seasonal): ?>
                <span class="bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded-full"><?php echo e($product->seasonal_label ?? 'Seasonal'); ?></span>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="p-4">
        
        <?php if($product->category): ?>
            <span class="text-xs font-medium text-coffee-400 uppercase tracking-wide"><?php echo e($product->category->name); ?></span>
        <?php endif; ?>

        <h3 class="font-bold text-coffee-800 mt-1 text-sm leading-tight"><?php echo e($product->name); ?></h3>

        
        <?php if($product->has_variants): ?>
            <div class="flex gap-1 mt-2">
                <button @click="variant='hot'; price=<?php echo e($product->price_hot ?? $product->price); ?>"
                        :class="variant==='hot' ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-600'"
                        class="text-xs font-bold px-3 py-1 rounded-full transition">🔥 Hot</button>
                <button @click="variant='cold'; price=<?php echo e($product->price_cold ?? $product->price); ?>"
                        :class="variant==='cold' ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'"
                        class="text-xs font-bold px-3 py-1 rounded-full transition">❄️ Cold</button>
            </div>
        <?php endif; ?>

        
        <div class="flex items-center justify-between mt-3">
            <div>
                <?php if($product->is_promo && $product->promo_price): ?>
                    <span class="text-xs text-gray-400 line-through"><?php echo e($product->formatted_original_price); ?></span>
                <?php endif; ?>
                <?php if($product->has_variants): ?>
                    <p class="text-coffee-600 font-bold" x-text="'Rp ' + price.toLocaleString('id-ID')"></p>
                <?php else: ?>
                    <p class="text-coffee-600 font-bold"><?php echo e($product->formatted_price); ?></p>
                <?php endif; ?>
            </div>

            
            <button @click="fetch('/cart/add', {method:'POST', headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'}, body:JSON.stringify({product_id: <?php echo e($product->id); ?>, variant: variant || null})}).then(r=>r.json()).then(d=>{if(d.success){window.dispatchEvent(new CustomEvent('cart-updated',{detail:{count:d.count}}));window.dispatchEvent(new CustomEvent('toast',{detail:{message:d.message}}))}})"
                    class="w-9 h-9 bg-coffee-600 hover:bg-coffee-700 text-white rounded-full flex items-center justify-center transition shadow-md">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
            </button>
        </div>
    </div>
</div>
<?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/partials/product-card.blade.php ENDPATH**/ ?>