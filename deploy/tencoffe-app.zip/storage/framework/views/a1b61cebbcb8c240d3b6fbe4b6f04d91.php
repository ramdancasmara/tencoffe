
<?php $__env->startSection('title', 'Keranjang - TenCoffe'); ?>
<?php $__env->startSection('content'); ?>

<div class="pt-20 pb-16 min-h-screen bg-coffee-50" x-data="cartPage()">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <h1 class="text-3xl font-extrabold text-coffee-800 mb-8">🛒 Keranjang Belanja</h1>

        <?php if(count($items) > 0): ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div class="lg:col-span-2 space-y-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-2xl p-4 shadow-sm flex items-center gap-4" id="cart-item-<?php echo e($item['key']); ?>">
                        <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" class="w-20 h-20 rounded-xl object-cover flex-shrink-0">
                        <div class="flex-1 min-w-0">
                            <h3 class="font-bold text-coffee-800 text-sm"><?php echo e($item['name']); ?></h3>
                            <div class="flex gap-1 mt-1">
                                <?php if($item['variant']): ?>
                                    <span class="text-xs <?php echo e($item['variant'] === 'hot' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'); ?> px-2 py-0.5 rounded-full font-bold"><?php echo e(ucfirst($item['variant'])); ?></span>
                                <?php endif; ?>
                                <?php if($item['type'] === 'event'): ?>
                                    <span class="text-xs bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full font-bold">🌙 Paket Ramadhan</span>
                                <?php endif; ?>
                            </div>
                            <p class="text-coffee-600 font-bold mt-1">Rp <?php echo e(number_format($item['price'], 0, ',', '.')); ?></p>
                        </div>
                        <div class="flex items-center gap-2">
                            <button @click="updateQty('<?php echo e($item['key']); ?>', <?php echo e($item['quantity'] - 1); ?>)" class="w-8 h-8 bg-coffee-100 hover:bg-coffee-200 rounded-full flex items-center justify-center text-coffee-700 font-bold transition">-</button>
                            <span class="w-8 text-center font-bold text-coffee-800"><?php echo e($item['quantity']); ?></span>
                            <button @click="updateQty('<?php echo e($item['key']); ?>', <?php echo e($item['quantity'] + 1); ?>)" class="w-8 h-8 bg-coffee-100 hover:bg-coffee-200 rounded-full flex items-center justify-center text-coffee-700 font-bold transition">+</button>
                        </div>
                        <button @click="removeItem('<?php echo e($item['key']); ?>')" class="text-red-400 hover:text-red-600 transition p-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl p-6 shadow-sm sticky top-24">
                    <h3 class="font-bold text-coffee-800 text-lg mb-4">Ringkasan</h3>
                    <div class="flex justify-between text-sm text-gray-600 mb-2">
                        <span>Total Item</span>
                        <span><?php echo e(collect($items)->sum('quantity')); ?></span>
                    </div>
                    <div class="border-t border-gray-100 my-3"></div>
                    <div class="flex justify-between font-bold text-coffee-800 text-lg">
                        <span>Total</span>
                        <span>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
                    </div>
                    <a href="<?php echo e(route('checkout')); ?>" class="btn-primary w-full mt-6 py-3 text-center rounded-xl block">Checkout →</a>
                    <a href="<?php echo e(route('menu')); ?>" class="btn-outline w-full mt-3 py-3 text-center rounded-xl block">← Lanjut Belanja</a>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="text-center py-20">
            <p class="text-6xl mb-4">🛒</p>
            <h3 class="text-xl font-bold text-coffee-700 mb-2">Keranjang kosong</h3>
            <p class="text-coffee-400 mb-6">Yuk, pilih menu favoritmu!</p>
            <a href="<?php echo e(route('menu')); ?>" class="btn-primary px-8 py-3 rounded-xl">Lihat Menu</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function cartPage() {
    return {
        updateQty(key, qty) {
            fetch('/cart/update', {
                method: 'PUT',
                headers: {'Content-Type':'application/json','X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content},
                body: JSON.stringify({cart_key: key, quantity: qty})
            }).then(r => r.json()).then(d => {
                if(d.success) {
                    window.dispatchEvent(new CustomEvent('cart-updated', {detail: {count: d.count}}));
                    location.reload();
                }
            });
        },
        removeItem(key) {
            fetch('/cart/remove', {
                method: 'DELETE',
                headers: {'Content-Type':'application/json','X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content},
                body: JSON.stringify({cart_key: key})
            }).then(r => r.json()).then(d => {
                if(d.success) {
                    window.dispatchEvent(new CustomEvent('cart-updated', {detail: {count: d.count}}));
                    location.reload();
                }
            });
        }
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/cart.blade.php ENDPATH**/ ?>