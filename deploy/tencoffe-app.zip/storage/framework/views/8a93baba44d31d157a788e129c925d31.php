
<?php $__env->startSection('page-title', 'Event Spesial'); ?>
<?php $__env->startSection('content'); ?>

<div class="space-y-6">
    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">⚙️ Pengaturan Event</h3>
        <form action="<?php echo e(route('admin.special-event.settings')); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <label class="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <input type="checkbox" name="enabled" value="1" <?php echo e(($settings['special_event_enabled'] ?? false) ? 'checked' : ''); ?> class="rounded border-coffee-300 text-coffee-600 w-5 h-5">
                <span class="font-medium">Tampilkan Event Spesial di Home</span>
            </label>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Emoji</label>
                    <input type="text" name="emoji" value="<?php echo e($settings['special_event_emoji'] ?? '🌙'); ?>" class="input-field">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Teks Badge</label>
                    <input type="text" name="badge" value="<?php echo e($settings['special_event_badge'] ?? 'Ramadhan Kareem'); ?>" class="input-field">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Judul Event</label>
                    <input type="text" name="title" value="<?php echo e($settings['special_event_title'] ?? 'Menu Ramadhan'); ?>" class="input-field">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                    <input type="text" name="subtitle" value="<?php echo e($settings['special_event_subtitle'] ?? ''); ?>" class="input-field">
                </div>
            </div>
            <button type="submit" class="btn-primary px-6 py-2 rounded-xl">Simpan Pengaturan</button>
        </form>
    </div>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">📤 Upload Gambar</h3>
        <form action="<?php echo e(route('admin.special-event.upload')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Gambar (multiple)</label>
                    <input type="file" name="images[]" multiple accept="image/*" required class="input-field">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Judul / Nama Paket</label>
                    <input type="text" name="title" placeholder="Paket Ramadhan 1" class="input-field">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi / Isi Paket</label>
                    <textarea name="description" rows="2" placeholder="Nasi Putih, Ayam Goreng, dll" class="input-field"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Harga (opsional)</label>
                    <input type="number" name="price" placeholder="0 = tanpa harga" class="input-field">
                </div>
            </div>
            <button type="submit" class="btn-primary px-6 py-2 rounded-xl">Upload</button>
        </form>
    </div>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">🖼️ Gallery Gambar</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-gray-50 rounded-xl overflow-hidden">
                    <img src="<?php echo e($gallery->image_url); ?>" class="w-full aspect-square object-cover">
                    <div class="p-3">
                        <p class="font-medium text-coffee-800 text-sm"><?php echo e($gallery->title ?? 'Tanpa judul'); ?></p>
                        <?php if($gallery->description): ?>
                            <p class="text-gray-500 text-xs mt-1 line-clamp-2"><?php echo e($gallery->description); ?></p>
                        <?php endif; ?>
                        <?php if($gallery->price): ?><p class="text-coffee-600 font-bold text-sm mt-1"><?php echo e($gallery->formatted_price); ?></p><?php endif; ?>
                        <span class="text-xs <?php echo e($gallery->is_active ? 'text-green-600' : 'text-gray-400'); ?>"><?php echo e($gallery->is_active ? 'Aktif' : 'Nonaktif'); ?></span>
                        <div class="flex gap-2 mt-2">
                            <form action="<?php echo e(route('admin.special-event.destroy', $gallery)); ?>" method="POST" onsubmit="return confirm('Hapus gambar ini?')" class="flex-1">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="w-full text-center text-xs text-red-500 hover:text-red-700 py-1 border border-red-200 rounded-lg">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-400 text-sm col-span-full text-center py-4">Belum ada gambar</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/admin/special-event/index.blade.php ENDPATH**/ ?>