
<?php $__env->startSection('title', 'Menu - TenCoffe'); ?>
<?php $__env->startSection('content'); ?>

<div class="pt-20 pb-16 min-h-screen bg-coffee-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10 pt-4">
            <h1 class="text-3xl md:text-4xl font-extrabold text-coffee-800">Menu Kami</h1>
            <p class="text-coffee-500 mt-2">Pilih menu favorit Anda</p>
        </div>

        
        <div class="flex flex-wrap justify-center gap-2 mb-10">
            <a href="<?php echo e(route('menu')); ?>" class="px-5 py-2 rounded-full text-sm font-bold transition <?php echo e(!isset($category) ? 'bg-coffee-600 text-white' : 'bg-white text-coffee-600 hover:bg-coffee-100'); ?>">Semua</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('menu.category', $cat->slug)); ?>" class="px-5 py-2 rounded-full text-sm font-bold transition <?php echo e(isset($category) && $category->id === $cat->id ? 'bg-coffee-600 text-white' : 'bg-white text-coffee-600 hover:bg-coffee-100'); ?>"><?php echo e($cat->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div x-data="{ visibleCount: 8, total: <?php echo e($products->count()); ?> }">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div x-show="<?php echo e($index); ?> < visibleCount" x-transition>
                        <?php echo $__env->make('partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div x-show="visibleCount < total" class="text-center py-16">
                <button @click="visibleCount += 8" class="btn-primary px-8 py-3 rounded-2xl text-lg">
                    Lihat Lainnya (<span x-text="Math.max(0, total - visibleCount)"></span> menu lagi)
                </button>
            </div>

            <?php if($products->isEmpty()): ?>
                <div class="text-center py-20">
                    <p class="text-6xl mb-4">☕</p>
                    <h3 class="text-xl font-bold text-coffee-700 mb-2">Belum ada menu</h3>
                    <p class="text-coffee-400">Menu akan segera tersedia</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/menu.blade.php ENDPATH**/ ?>