
<?php $__env->startSection('page-title', 'Pengaturan'); ?>
<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" class="space-y-6 max-w-3xl">
    <?php echo csrf_field(); ?>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">🏪 Umum</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Nama Toko</label>
                <input type="text" name="site_name" value="<?php echo e($general['site_name'] ?? 'TenCoffe'); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Tagline</label>
                <input type="text" name="tagline" value="<?php echo e($general['tagline'] ?? ''); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" value="<?php echo e($general['email'] ?? ''); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Telepon</label>
                <input type="text" name="phone" value="<?php echo e($general['phone'] ?? ''); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Telepon 2</label>
                <input type="text" name="phone2" value="<?php echo e($general['phone2'] ?? ''); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Jam Operasional</label>
                <input type="text" name="operating_hours" value="<?php echo e($general['operating_hours'] ?? ''); ?>" class="input-field">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                <textarea name="address" rows="2" class="input-field"><?php echo e($general['address'] ?? ''); ?></textarea>
            </div>
        </div>
    </div>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">📱 Sosial Media</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Instagram URL</label>
                <input type="text" name="instagram" value="<?php echo e($social['instagram'] ?? ''); ?>" class="input-field" placeholder="https://instagram.com/...">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">TikTok URL</label>
                <input type="text" name="tiktok" value="<?php echo e($social['tiktok'] ?? ''); ?>" class="input-field" placeholder="https://tiktok.com/...">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">WhatsApp</label>
                <input type="text" name="whatsapp" value="<?php echo e($social['whatsapp'] ?? ''); ?>" class="input-field" placeholder="628xxxxxxxxxx">
            </div>
        </div>
    </div>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">📦 Pesanan</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">WhatsApp Pesanan</label>
                <input type="text" name="store_whatsapp" value="<?php echo e($order['store_whatsapp'] ?? ''); ?>" class="input-field" placeholder="628xxxxxxxxxx">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Min. Order (Rp)</label>
                <input type="number" name="min_order" value="<?php echo e($order['min_order'] ?? 0); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Ongkos Kirim (Rp)</label>
                <input type="number" name="delivery_fee" value="<?php echo e($order['delivery_fee'] ?? 10000); ?>" class="input-field">
            </div>
        </div>
    </div>

    
    <div class="card">
        <h3 class="font-bold text-coffee-800 text-lg mb-4">💳 Payment Gateway (Duitku)</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Mode</label>
                <select name="duitku_mode" class="input-field">
                    <option value="sandbox" <?php echo e(($payment['duitku_mode'] ?? 'sandbox') === 'sandbox' ? 'selected' : ''); ?>>Sandbox</option>
                    <option value="production" <?php echo e(($payment['duitku_mode'] ?? '') === 'production' ? 'selected' : ''); ?>>Production</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Merchant Code</label>
                <input type="text" name="duitku_merchant_code" value="<?php echo e($payment['duitku_merchant_code'] ?? ''); ?>" class="input-field">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">API Key</label>
                <input type="text" name="duitku_api_key" value="<?php echo e($payment['duitku_api_key'] ?? ''); ?>" class="input-field">
            </div>
            <div class="flex items-end">
                <label class="flex items-center gap-2 p-3 bg-gray-50 rounded-xl w-full">
                    <input type="checkbox" name="duitku_enabled" value="1" <?php echo e(($payment['duitku_enabled'] ?? false) ? 'checked' : ''); ?> class="rounded border-coffee-300 text-coffee-600">
                    <span class="text-sm font-medium">Aktifkan Duitku</span>
                </label>
            </div>
        </div>
    </div>

    <button type="submit" class="btn-primary px-8 py-3 rounded-xl text-lg">Simpan Semua Pengaturan</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\APLIKASI\HERD\tencoffe\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>